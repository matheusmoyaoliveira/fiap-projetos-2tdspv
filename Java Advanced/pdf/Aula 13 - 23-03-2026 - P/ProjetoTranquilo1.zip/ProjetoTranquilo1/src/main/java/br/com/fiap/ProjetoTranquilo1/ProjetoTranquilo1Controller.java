package br.com.fiap.ProjetoTranquilo1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProjetoTranquilo1Controller {

    @RequestMapping("/Tranquis")
    public String index(){
        return "<h1> ******* TRANQUILO ****** </h1>";
    }
}
